<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Print Invoice</title>
    <style>
        html, body {
            margin: 0;
            padding: 0;
            font-size: 12px;
            background-color: #fff;
        }

        #products {
            width: 100%;
            margin-top: 30px;
            margin-bottom: 30px;
        }

        #products tr td {
            font-size: 12px;
        }

        #printbox {
            width: 2480px;
            margin: 5pt;
            padding: 5px;
            text-align: justify;
        }

        .inv_info tr td {
            padding-right: 10pt;
        }

        .product_row {
            margin: 15pt;
        }

        .stamp {
            margin: 5pt;
            padding: 3pt;
            border: 3pt solid #111;
            text-align: center;
            font-size: 20pt;
            color
        }

        .text-center {
            text-align: center;
        }
        .text-left {
            text-align: left;
        }
        .bordered-cell{
            border: 1px solid black;
            border-collapse: collapse;
            padding: 5px;
        }
    </style>
</head>
<body dir="<?= LTR ?>">

<div id='printbox'>
    <table style=" border-collapse: collapse;">
        <tr>
            <td><img src="<?php echo base_url();?>res/assets/images/oakwood.jpeg" style="height: 100px;"></td>
            <td style="padding-left: 20px;"></td>
            <td>
                <h2 style="margin-top:0;font-size: 22px;color: #535354;" class="text-left"><span style="color: #043161;">Oakwood Hospital Ltd.</span><br>
                <b style="font-size: 12px;">Kikuyu / Gikambura/ Dagoretti Road off Southern Bypass<br></b>
                <b style="font-size: 12px;">P O. Box 395-10230<br></b>
                    <br><b style="font-size: 12px;">TEL: 0720 126 297<br>Email: info@oakwoodhospital.co.ke</b></h2>
            </td>
            <td colspan="3" style="color: white; padding-left: 150px;"></td>
            <td style="background-color: #055797;padding-left: 5px;"></td>
            <td style="background-color: #900309;padding-left: 5px;"></td>
            <td style="background-color: #6E6D6D;padding-left: 5px;"></td>
        </tr>
    </table>
    <hr>

    <table class="inv_info">
        <tr class="product_row">
            <td><b>NAME: </b></td>
            <td><?php echo $patientdetails['name']." ".$patientdetails['lname']; ?></td>
            <td><b>AGE: </b></td>
            <td><?php echo(date('Y-m-d') - $patientdetails['dob']); ?></td>
        </tr>
        <tr class="product_row">
            <td><b>GENDER: </b></td>
            <td><?php echo $patientdetails['gender'];?></td>
            <td><b>TEST: </b></td>
            <td><?php echo $patientdetails['']; ?></td>
        </tr>
        <tr class="product_row">
            <td><b>PRINTED BY: </b></td>
            <td><?php echo $this->session->userdata('user_aob')->name;?></td>
            <td><b>DATE: </b></td>
            <td><?php echo date('Y-m-d H:i:s');?></td>
        </tr>
        <tr class="product_row">
            <td colspan="4">
               
            </td>
        </tr>
        
    </table>
   
    <hr>
    <table>
        
        <tr>
           <td colspan="3">
               &nbsp; 
            </td> 
        </tr>
        
        <tr>
           <td>Tests by: </td> 
           <td><?php echo $tests_by;?></td>
        </tr>
         <tr>
           <td colspan="3">
               &nbsp; 
            </td> 
        </tr>
        <tr>
           <td>Sign: </td> 
           <td>................................</td>
        </tr>
        <tr>
           <td colspan="3">
               &nbsp;
            </td> 
        </tr>
        <tr>
           <td colspan="3">
                &nbsp;
            </td> 
        </tr>
        <tr>
           <td>Stamp: </td> 
           <td></td>
        </tr>
        <tr>
           <td colspan="3">
               &nbsp;
            </td> 
        </tr>
        <tr>
           <td colspan="3">
               &nbsp;
            </td> 
        </tr>
    </table>
    
</div>
</body>
</html>
