<div class="app-main__outer">
    <div class="app-main__inner">

        <div class="row">
            <div class="col-lg-12">
                <div class="main-card mb-3 card">
                    <div class="card-header"><i class="header-icon lnr-license icon-gradient bg-plum-plate"> </i>INCOMING
                        PATIENTS

                    </div>
                    <div class="card-body">
                        <table class="mb-0 table table-striped">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>P/No</th>
                                <th>Name</th>
                                <th>Sent From</th>
                                <th>Triage</th>
                                <th>Time In</th>
                                <th>*</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <th scope="row">1</th>
                                <td>1203</td>
                                <td>Daniel Mutuku</td>
                                <td>Radiology</td>
                                <td>View</td>
                                <td>5/1/2020 11:20</td>
                                <td><a href="<?php echo base_url(); ?>dashboard/editpatient/1">Edit</a></td>
                            </tr>
                            <tr>
                                <th scope="row">2</th>
                                <td>1203</td>
                                <td>Daniel Mutuku</td>
                                <td>Radiology</td>
                                <td>View</td>
                                <td>5/1/2020 11:20</td>
                                <td><a href="<?php echo base_url(); ?>dashboard/editpatient/1">Edit</a></td>
                            </tr>

                            </tbody>
                        </table>
                    </div>

                </div>
            </div>

        </div>
    </div>